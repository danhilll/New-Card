import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

export default function ProfileCard({ profile, number }) {
  const initials = profile.name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0].toUpperCase())
    .join('');

  return (
    <View style={styles.card}>
      <View style={styles.topRow}>
        <View style={styles.avatar}>
          <Text style={styles.initials}>{initials}</Text>
          <View style={styles.onlineDot} />
        </View>
        <View style={styles.identity}>
          <Text style={styles.kicker}>STUDENT PROFILE</Text>
          <Text style={styles.name}>{profile.name}</Text>
        </View>
        <View style={styles.moreButton}>
          <Text style={styles.more}>•••</Text>
        </View>
      </View>

      <View style={styles.divider} />

      <View style={styles.details}>
        <View style={styles.detailRow}>
          <View style={[styles.detailIcon, styles.blueIcon]}>
            <Text style={styles.blueIconText}>✦</Text>
          </View>
          <View style={styles.detailText}>
            <Text style={styles.detailLabel}>PROGRAM</Text>
            <Text style={styles.detailValue}>{profile.course}</Text>
          </View>
        </View>

        <View style={styles.detailRow}>
          <View style={[styles.detailIcon, styles.greenIcon]}>
            <Text style={styles.greenIconText}>↗</Text>
          </View>
          <View style={styles.detailText}>
            <Text style={styles.detailLabel}>YEAR LEVEL</Text>
            <Text style={styles.detailValue}>{profile.year}</Text>
          </View>
        </View>
      </View>

      <View style={styles.bottomRow}>
        <View style={styles.majorPill}>
          <View style={styles.pillDot} />
          <Text style={styles.majorText}>{profile.major}</Text>
        </View>
        <Text style={styles.cardNumber}>#{String(number).padStart(2, '0')}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 25,
    padding: 20,
    borderWidth: 1,
    borderColor: '#ECEEF5',
    shadowColor: '#20294D',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.07,
    shadowRadius: 20,
    elevation: 3,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 19,
    backgroundColor: '#E9EDFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  initials: {
    color: '#5267E8',
    fontSize: 19,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  onlineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#48C99A',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    position: 'absolute',
    right: -1,
    bottom: 0,
  },
  identity: {
    flex: 1,
    marginLeft: 13,
  },
  kicker: {
    color: '#9298A8',
    fontSize: 9,
    letterSpacing: 1.15,
    fontWeight: '800',
    marginBottom: 4,
  },
  name: {
    color: '#202437',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  moreButton: {
    width: 32,
    height: 32,
    borderRadius: 11,
    backgroundColor: '#F6F7FA',
    alignItems: 'center',
    justifyContent: 'center',
  },
  more: {
    color: '#83899A',
    fontSize: 12,
    letterSpacing: 1,
  },
  divider: {
    height: 1,
    backgroundColor: '#EEF0F5',
    marginVertical: 17,
  },
  details: {
    gap: 14,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailIcon: {
    width: 34,
    height: 34,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  blueIcon: {
    backgroundColor: '#EEF0FF',
  },
  greenIcon: {
    backgroundColor: '#EAF8F2',
  },
  blueIconText: {
    color: '#5367E8',
    fontSize: 15,
    fontWeight: '700',
  },
  greenIconText: {
    color: '#39A982',
    fontSize: 16,
    fontWeight: '700',
  },
  detailText: {
    flex: 1,
    marginLeft: 11,
  },
  detailLabel: {
    color: '#969BAA',
    fontSize: 9,
    letterSpacing: 0.9,
    fontWeight: '800',
    marginBottom: 3,
  },
  detailValue: {
    color: '#31364A',
    fontSize: 12,
    lineHeight: 17,
    fontWeight: '600',
  },
  bottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 18,
  },
  majorPill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: '#F4F5FF',
    borderRadius: 999,
    paddingVertical: 8,
    paddingHorizontal: 11,
    maxWidth: '88%',
  },
  pillDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#6576EB',
    marginRight: 7,
  },
  majorText: {
    color: '#5667C6',
    fontSize: 10,
    fontWeight: '700',
    flexShrink: 1,
  },
  cardNumber: {
    color: '#B1B5C0',
    fontSize: 10,
    fontWeight: '700',
    marginLeft: 8,
  },
});
