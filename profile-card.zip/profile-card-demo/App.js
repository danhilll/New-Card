import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import ProfileCard from './components/ProfileCard';
import PrimaryButton from './components/PrimaryButton';

const studentProfile = {
  name: 'Nash Danhill',
  course: 'Bachelor of Science in Information Technology',
  year: '4th Year',
  major: 'Web & Mobile Application',
};

export default function App() {
  const [profiles, setProfiles] = useState([]);

  const addProfile = () => {
    setProfiles((current) => [
      ...current,
      { ...studentProfile, id: `${Date.now()}-${Math.random()}` },
    ]);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#F4F6FB" />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.brandMark}>
            <Text style={styles.brandMarkText}>P</Text>
          </View>
          <Text style={styles.headerLabel}>PROFILE STUDIO</Text>
        </View>

        <View style={styles.intro}>
          <Text style={styles.eyebrow}>YOUR COMPONENT DEMO</Text>
          <Text style={styles.title}>Build your{ '\n' }profile card.</Text>
          <Text style={styles.description}>
            Tap the button to add a polished student profile to your screen.
          </Text>
        </View>

        <View style={styles.actionArea}>
          <PrimaryButton onPress={addProfile} />
          <Text style={styles.helperText}>
            {profiles.length === 0
              ? 'Your profile card will appear below.'
              : `${profiles.length} profile ${profiles.length === 1 ? 'card' : 'cards'} added`}
          </Text>
        </View>

        <View style={styles.cards}>
          {profiles.length === 0 ? (
            <View style={styles.emptyState}>
              <View style={styles.emptyIcon}>
                <Text style={styles.emptyIconText}>＋</Text>
              </View>
              <Text style={styles.emptyTitle}>A little space for you</Text>
              <Text style={styles.emptyDescription}>
                Your profile card will show up here when you add it.
              </Text>
            </View>
          ) : (
            profiles.map((profile, index) => (
              <ProfileCard key={profile.id} profile={profile} number={index + 1} />
            ))
          )}
        </View>

        <Text style={styles.footer}>Made for your next great idea.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F4F6FB',
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  brandMark: {
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: '#5267E8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandMarkText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
  },
  headerLabel: {
    color: '#6D7487',
    fontSize: 11,
    letterSpacing: 1.7,
    fontWeight: '800',
  },
  intro: {
    marginTop: 44,
  },
  eyebrow: {
    color: '#5367E8',
    fontSize: 11,
    letterSpacing: 1.5,
    fontWeight: '800',
    marginBottom: 10,
  },
  title: {
    color: '#171B2B',
    fontSize: 38,
    lineHeight: 43,
    letterSpacing: -1.2,
    fontWeight: '800',
  },
  description: {
    color: '#747B8D',
    fontSize: 15,
    lineHeight: 23,
    marginTop: 12,
    maxWidth: 320,
  },
  actionArea: {
    marginTop: 27,
  },
  helperText: {
    color: '#858B9A',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 12,
  },
  cards: {
    marginTop: 28,
    gap: 14,
  },
  emptyState: {
    minHeight: 190,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#E3E7F0',
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: 'rgba(255,255,255,0.58)',
  },
  emptyIcon: {
    width: 42,
    height: 42,
    borderRadius: 15,
    backgroundColor: '#E9EDFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  emptyIconText: {
    color: '#5367E8',
    fontSize: 24,
    lineHeight: 27,
    fontWeight: '500',
  },
  emptyTitle: {
    color: '#2A3041',
    fontSize: 15,
    fontWeight: '700',
  },
  emptyDescription: {
    color: '#858B9A',
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
    marginTop: 6,
    maxWidth: 230,
  },
  footer: {
    color: '#A0A5B2',
    fontSize: 11,
    textAlign: 'center',
    marginTop: 26,
  },
});
