# Student Profile Card Demo

A small React Native screen with a custom button that adds a profile card when tapped.

## Files

- `App.js` — screen and button behavior
- `components/PrimaryButton.js` — custom iOS-inspired button
- `components/ProfileCard.js` — reusable student profile card

## Add to a React Native app

Copy `App.js` and the `components` folder into your React Native project's source folder. Keep the folder structure so the imports in `App.js` work. Set `App` as your app's root component. No icon, navigation, or UI packages are required.

The profile details are defined near the top of `App.js` in `studentProfile`. Update them there if you want to change the displayed name, program, year, or major.
